Open Enterprise Search Platform (OpenESP)
=========================================
Welcome to OpenESP, the Open Source Enterprise Search Platform.
OpenESP bundles together the following components into an installable package:
 * Apache Solr
 * Apache Tomcat

The project is initiated and sponsored by Cominvent AS (www.cominvent.com)
and lives on www.openesp.org and here on GitHub.

The project is licensed under the Apache Software License v2.0, see LICENSE.txt